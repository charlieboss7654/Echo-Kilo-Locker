local DATA_FILE = 'data/personal_outfits.json'  -- Ensure a 'data' folder exists in the resource
local personal = {}  -- [identifier] = { { name=..., desc=..., outfit={...} }, ... }

local function loadData()
    local raw = LoadResourceFile(GetCurrentResourceName(), DATA_FILE)
    if raw and #raw > 0 then
        local ok, decoded = pcall(json.decode, raw)
        if ok and type(decoded) == 'table' then
            personal = decoded
            -- Backfill desc for older entries
            for _, list in pairs(personal) do
                for _, e in ipairs(list) do
                    if e.desc == nil then e.desc = '' end
                end
            end
            return
        end
    end
    personal = {}
end

local function saveData()
    local payload = json.encode(personal, { indent = true })
    SaveResourceFile(GetCurrentResourceName(), DATA_FILE, payload or "{}", -1)
end

local function getIdentifier(src)
    local id = GetPlayerIdentifierByType(src, 'license2') or GetPlayerIdentifierByType(src, 'license')
    if id and id ~= '' then return id end
    for i = 0, GetNumPlayerIdentifiers(src) - 1 do
        local v = GetPlayerIdentifier(src, i)
        if v and v ~= '' then return v end
    end
    return ('temp:%s'):format(tostring(src))
end

AddEventHandler('onResourceStart', function(res)
    if res ~= GetCurrentResourceName() then return end
    loadData()
    if next(personal) == nil then
        saveData() -- ensure file exists on disk
    end
end)

lib.callback.register('eks_ul:getPersonal', function(source)
    local id = getIdentifier(source)
    return personal[id] or {}
end)

lib.callback.register('eks_ul:savePersonal', function(source, name, outfit, desc)
    if type(name) ~= 'string' or name == '' then return false, nil end
    if type(outfit) ~= 'table' then return false, nil end
    name = name:sub(1, 40)
    desc = (type(desc) == 'string' and desc or ''):sub(1, 120)

    local id = getIdentifier(source)
    personal[id] = personal[id] or {}

    local replaced = false
    for i, entry in ipairs(personal[id]) do
        if entry.name == name then
            personal[id][i] = { name = name, desc = desc, outfit = outfit }
            replaced = true
            break
        end
    end
    if not replaced then
        table.insert(personal[id], { name = name, desc = desc, outfit = outfit })
    end

    saveData()
    return true, personal[id]
end)

lib.callback.register('eks_ul:deletePersonal', function(source, name)
    if type(name) ~= 'string' or name == '' then return false, nil end
    local id = getIdentifier(source)
    local list = personal[id] or {}
    local new = {}
    for _, entry in ipairs(list) do
        if entry.name ~= name then
            new[#new + 1] = entry
        end
    end
    personal[id] = new
    saveData()
    return true, new
end)

-- ?? InteractSound Trigger (REQUIRED for client sounds to work)
RegisterServerEvent('InteractSound_SV:PlayOnSource')
AddEventHandler('InteractSound_SV:PlayOnSource', function(soundFile, soundVolume)
    TriggerClientEvent('InteractSound_CL:PlayOnOne', source, soundFile, soundVolume)
end)
