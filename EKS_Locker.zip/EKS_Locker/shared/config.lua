--[[
  EKS Uniform Locker � config.lua
  --------------------------------------------------------------------
  How it works
  - Each locker LOCATION points to a PRESET GROUP (by key).
  - When a player opens a locker, the UI shows all presets from that
    group's list (no sex filtering; make separate presets if needed).
  - Personal outfits are global to the player (not per-location).

  Optional fields
  - desc = "Short description shown on the card" for each preset.

  Component indices (SetPedComponentVariation)
    [0]=Face, [1]=Mask, [2]=Hair, [3]=Torso, [4]=Legs, [5]=Bag/Parachute,
    [6]=Shoes, [7]=Accessories, [8]=Undershirt, [9]=Body Armor,
    [10]=Decals, [11]=Tops

  Prop indices (SetPedPropIndex / ClearPedProp)
    [0]=Hat/Helmet, [1]=Glasses, [2]=Ears, [3]=Watch, [4]=Bracelet
    (Use drawable = -1 to clear a prop slot)

  Notes
  - Presets are applied over the current ped; invalid parts are skipped.
  - For components: palette can be 0..3 (optional).
  - Add more locations: append to Config.Locations with a presetGroup key.
  - Add more groups/outfits: add entries under Config.PresetGroups[YourKey].
]]--

Config = {}

----------------------------------------------------------------------
-- Locker Locations (each bound to a presetGroup key)
----------------------------------------------------------------------
Config.Locations = {
  -- MRPD (Mission Row)
  { coords = vec3(451.67, -992.57, 30.69), radius = 1.8, label = 'MRPD Locker',    presetGroup = 'MRPD'   },

  -- Sandy Shores
  { coords = vec3(1851.12, 3690.47, 34.27), radius = 1.8, label = 'Sandy Locker',  presetGroup = 'SANDY'  },

  -- Paleto Bay
  { coords = vec3(-450.12, 6011.25, 31.72), radius = 1.8, label = 'Paleto Locker', presetGroup = 'PALETO' },
}

----------------------------------------------------------------------
-- Preset Groups (per-location outfit lists)
-- Tip: Duplicate any entry and tweak drawables/textures for your packs.
----------------------------------------------------------------------
Config.PresetGroups = {

  --------------------------------------------------------------------
  -- MRPD
  --------------------------------------------------------------------
  MRPD = {
    {
      name = 'LEO Patrol (Male) � MRPD',
      desc = 'Standard patrol uniform with hat.',
      components = {
        [0]={drawable=0, texture=0},   -- Face
        [1]={drawable=0, texture=0},   -- Mask
        [2]={drawable=5, texture=0},   -- Hair
        [3]={drawable=30,texture=0},   -- Torso
        [4]={drawable=35,texture=0},   -- Legs
        [5]={drawable=0, texture=0},   -- Bag/Parachute
        [6]={drawable=25,texture=0},   -- Shoes
        [7]={drawable=0, texture=0},   -- Accessories
        [8]={drawable=58,texture=0},   -- Undershirt
        [9]={drawable=4, texture=0},   -- Body Armor
        [10]={drawable=0,texture=0},   -- Decals
        [11]={drawable=55,texture=0},  -- Tops
      },
      props = {
        [0]={drawable=46,texture=0},   -- Hat
        [1]={drawable=-1,texture=0},   -- Glasses (cleared)
      }
    },
    {
      name = 'LEO Patrol (Female) � MRPD',
      desc = 'Female variant with body armor and undershirt.',
      components = {
        [0]={drawable=0, texture=0},   -- Face
        [1]={drawable=0, texture=0},   -- Mask
        [2]={drawable=7, texture=0},   -- Hair
        [3]={drawable=30,texture=0},   -- Torso
        [4]={drawable=35,texture=0},   -- Legs
        [5]={drawable=0, texture=0},   -- Bag/Parachute
        [6]={drawable=25,texture=0},   -- Shoes
        [7]={drawable=0, texture=0},   -- Accessories
        [8]={drawable=57,texture=0},   -- Undershirt
        [9]={drawable=4, texture=0},   -- Body Armor
        [10]={drawable=0,texture=0},   -- Decals
        [11]={drawable=48,texture=0},  -- Tops
      },
      props = {
        [0]={drawable=46,texture=0},   -- Hat
        [1]={drawable=-1,texture=0},   -- Glasses (cleared)
      }
    },
  },

  --------------------------------------------------------------------
  -- SANDY
  --------------------------------------------------------------------
  SANDY = {
    {
      name = 'Sheriff (Male) � Sandy',
      desc = 'Sheriff patrol kit with tan legs and campaign hat.',
      components = {
        [0]={drawable=0, texture=0},
        [1]={drawable=0, texture=0},
        [2]={drawable=10,texture=0},
        [3]={drawable=17,texture=0},
        [4]={drawable=45,texture=1},
        [5]={drawable=0, texture=0},
        [6]={drawable=24,texture=0},
        [7]={drawable=1, texture=0},
        [8]={drawable=20,texture=0},
        [9]={drawable=0, texture=0},
        [10]={drawable=0,texture=0},
        [11]={drawable=13,texture=2},
      },
      props = {
        [0]={drawable=58,texture=0},   -- Hat
        [1]={drawable=-1,texture=0},   -- Glasses (cleared)
      }
    },
    {
      name = 'Sheriff (Female) � Sandy',
      desc = 'Female sheriff variant with fitted top.',
      components = {
        [0]={drawable=0, texture=0},
        [1]={drawable=0, texture=0},
        [2]={drawable=12,texture=0},
        [3]={drawable=17,texture=0},
        [4]={drawable=44,texture=1},
        [5]={drawable=0, texture=0},
        [6]={drawable=24,texture=0},
        [7]={drawable=1, texture=0},
        [8]={drawable=19,texture=0},
        [9]={drawable=0, texture=0},
        [10]={drawable=0,texture=0},
        [11]={drawable=7, texture=2},
      },
      props = {
        [0]={drawable=58,texture=0},
        [1]={drawable=-1,texture=0},
      }
    },
  },

  --------------------------------------------------------------------
  -- PALETO
  --------------------------------------------------------------------
  PALETO = {
    {
      name = 'Rural Patrol (Male) � Paleto',
      desc = 'Rural-friendly loadout with rugged boots.',
      components = {
        [0]={drawable=0, texture=0},
        [1]={drawable=0, texture=0},
        [2]={drawable=4, texture=0},
        [3]={drawable=14,texture=0},
        [4]={drawable=21,texture=3},
        [5]={drawable=0, texture=0},
        [6]={drawable=12,texture=0},
        [7]={drawable=0, texture=0},
        [8]={drawable=16,texture=0},
        [9]={drawable=0, texture=0},
        [10]={drawable=0,texture=0},
        [11]={drawable=9, texture=1},
      },
      props = {
        [0]={drawable=-1,texture=0},   -- Hat (cleared)
      }
    },
    {
      name = 'Rural Patrol (Female) � Paleto',
      desc = 'Female rural variant with rolled sleeves.',
      components = {
        [0]={drawable=0, texture=0},
        [1]={drawable=0, texture=0},
        [2]={drawable=6, texture=0},
        [3]={drawable=14,texture=0},
        [4]={drawable=22,texture=3},
        [5]={drawable=0, texture=0},
        [6]={drawable=13,texture=0},
        [7]={drawable=0, texture=0},
        [8]={drawable=15,texture=0},
        [9]={drawable=0, texture=0},
        [10]={drawable=0,texture=0},
        [11]={drawable=10,texture=1},
      },
      props = {
        [0]={drawable=-1,texture=0},
      }
    },
  },
}

----------------------------------------------------------------------
-- Debug
----------------------------------------------------------------------
-- If true, shows ox_target sphere zones to help place lockers.
Config.DebugZones = false
