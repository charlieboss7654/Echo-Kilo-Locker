fx_version 'cerulean'
game 'gta5'
lua54 'yes'

name 'Echo Kilo Lockers!'
author 'Cowboy - Echo Kilo studios'
description 'Uniform Locker with Presets & Personal Outfits + Hover Preview'
version '1.0.0'

ui_page 'html/index.html'

files {
    'html/index.html',
    'html/style.css',
    'html/script.js',
    'html/sounds/lockerclose.ogg',
    'html/fonts/Inter-VariableFont.ttf'
}

shared_script '@ox_lib/init.lua'

client_scripts {
    'shared/config.lua',
    'client/main.lua'
}

server_scripts {
    'server/main.lua'
}
