local isOpen, currentGroup = false, nil
local original, lastPermanent = nil, nil

CreateThread(function()
    Wait(250)
    SendNUIMessage({ action = 'hardHide' })
    SetNuiFocus(false, false)
end)

AddEventHandler('onResourceStart', function(res)
    if res ~= GetCurrentResourceName() then return end
    SendNUIMessage({ action = 'hardHide' })
    SetNuiFocus(false, false)
end)

local function deepCopy(t)
    if type(t) ~= 'table' then return t end
    local r = {}
    for k, v in pairs(t) do r[k] = deepCopy(v) end
    return r
end

local function clamp(n, lo, hi)
    if not n then return lo end
    if n < lo then return lo elseif n > hi then return hi else return n end
end

local function normalizeIndexed(t)
    local out = {}
    if type(t) ~= 'table' then return out end
    for k, v in pairs(t) do
        local nk = (type(k) == 'number') and k or tonumber(k)
        if nk ~= nil then out[nk] = v else out[k] = v end
    end
    return out
end

local function captureCurrentOutfit(ped)
    local comp, props = {}, {}
    for i = 0, 11 do
        if i ~= 2 then
            comp[i] = {
                drawable = GetPedDrawableVariation(ped, i),
                texture = GetPedTextureVariation(ped, i),
                palette = GetPedPaletteVariation(ped, i)
            }
        end
    end
    for p = 0, 7 do
        local d = GetPedPropIndex(ped, p)
        local t = GetPedPropTextureIndex(ped, p)
        props[p] = (d == -1) and { drawable = -1, texture = 0 } or { drawable = d, texture = t }
    end
    return { components = comp, props = props }
end

local function applyOutfit(ped, outfit)
    if type(outfit) ~= 'table' then return end
    local comps, prps = normalizeIndexed(outfit.components), normalizeIndexed(outfit.props)
    if comps then
        for i = 0, 11 do
            if i ~= 2 then
                local c = comps[i]
                if c and c.drawable ~= nil then
                    local d = tonumber(c.drawable) or 0
                    local maxD = GetNumberOfPedDrawableVariations(ped, i) or 0
                    if maxD > 0 and d >= 0 and d < maxD then
                        local maxT = GetNumberOfPedTextureVariations(ped, i, d) or 1
                        local tx = clamp(tonumber(c.texture) or 0, 0, math.max(maxT - 1, 0))
                        if IsPedComponentVariationValid(ped, i, d, tx) then
                            SetPedComponentVariation(ped, i, d, tx, tonumber(c.palette) or 0)
                        else
                            for tt = 0, math.max(maxT - 1, 0) do
                                if IsPedComponentVariationValid(ped, i, d, tt) then
                                    SetPedComponentVariation(ped, i, d, tt, tonumber(c.palette) or 0)
                                    break
                                end
                            end
                        end
                    end
                end
            end
        end
    end

    if prps then
        for p = 0, 7 do
            local pr = prps[p]
            if pr and pr.drawable ~= nil then
                local d = tonumber(pr.drawable) or -1
                if d == -1 then
                    ClearPedProp(ped, p)
                else
                    local maxD = GetNumberOfPedPropDrawableVariations(ped, p) or 0
                    if maxD > 0 and d >= 0 and d < maxD then
                        local maxT = GetNumberOfPedPropTextureVariations(ped, p, d) or 1
                        local tx = clamp(tonumber(pr.texture) or 0, 0, math.max(maxT - 1, 0))
                        SetPedPropIndex(ped, p, d, tx, true)
                    end
                end
            end
        end
    end
end

local function getPresetList()
    local groupKey = currentGroup or 'DEFAULT'
    local groupList = (Config.PresetGroups and Config.PresetGroups[groupKey]) or {}
    local out = {}
    for _, p in ipairs(groupList) do
        out[#out + 1] = {
            name = p.name,
            desc = p.desc or '',
            components = p.components,
            props = p.props
        }
    end
    return out
end

local function openUI(groupKey)
    if isOpen then return end
    currentGroup = groupKey or currentGroup or 'DEFAULT'

    local ped = PlayerPedId()
    original = captureCurrentOutfit(ped)
    lastPermanent = deepCopy(original)

    isOpen = true
    SetNuiFocus(true, true)
    SetNuiFocusKeepInput(false)

    local presets = getPresetList()
    local personal = lib.callback.await('eks_ul:getPersonal', false)
    SendNUIMessage({ action = 'open', payload = { presets = presets, personal = personal or {} } })
end

local function closeUI()
    if not isOpen then return end
    SendNUIMessage({ action = 'playSound' }) -- ?? play sound via JS
    SetNuiFocus(false, false)
    isOpen = false
end

CreateThread(function()
    for i, spot in ipairs(Config.Locations or {}) do
        exports.ox_target:addSphereZone({
            coords = spot.coords,
            radius = spot.radius or 1.6,
            debug = Config.DebugZones or false,
            options = {{
                name = ('eks_ul_zone_%d'):format(i),
                label = spot.label or 'Open Locker',
                icon = 'fa-solid fa-shirt',
                onSelect = function() openUI(spot.presetGroup) end
            }}
        })
    end
end)

RegisterNUICallback('ui:ready', function(_, cb) cb(1) end)

RegisterNUICallback('ui:close', function(_, cb)
    closeUI()
    cb(1)
end)

RegisterNUICallback('outfit:equip', function(data, cb)
    applyOutfit(PlayerPedId(), data.outfit)
    lastPermanent = captureCurrentOutfit(PlayerPedId())
    SendNUIMessage({ action = 'playSound' }) -- ?? play sound
    closeUI()
    cb(1)
end)

RegisterNUICallback('personal:save', function(data, cb)
    local snap = captureCurrentOutfit(PlayerPedId())
    local name = tostring(data and data.name or 'Saved Outfit')
    local desc = tostring(data and data.desc or '')
    local ok, list = lib.callback.await('eks_ul:savePersonal', false, name, snap, desc)
    cb({ ok = ok, personal = list or {} })
end)

RegisterNUICallback('personal:delete', function(data, cb)
    local name = tostring(data and data.name or '')
    local ok, list = lib.callback.await('eks_ul:deletePersonal', false, name)
    cb({ ok = ok, personal = list or {} })
end)

AddEventHandler('onResourceStop', function(res)
    if res ~= GetCurrentResourceName() then return end
    if isOpen then SetNuiFocus(false, false) end
end)
