const RES = (typeof GetParentResourceName === 'function') ? GetParentResourceName() : 'eks_locker';

const app = document.getElementById('app');
document.documentElement.style.background = 'transparent';
document.body.style.background = 'transparent';
app.classList.add('hidden');

const closeBtn      = document.getElementById('closeBtn');
const tabs          = document.querySelectorAll('.tab');

const presetPanel   = document.getElementById('presetPanel');
const personalPanel = document.getElementById('personalPanel');

const presetGrid    = document.getElementById('presetGrid');
const personalGrid  = document.getElementById('personalGrid');

const searchInput   = document.getElementById('searchInput');
const searchPersonal= document.getElementById('searchPersonal');

const saveName      = document.getElementById('saveName');
const saveDesc      = document.getElementById('saveDesc');
const saveBtn       = document.getElementById('saveBtn');

const audioEl       = document.getElementById('locker-audio');

let state = { presets: [], personal: [], qPresets: '', qPersonal: '' };

function setVisible(v){ app.classList.toggle('hidden', !v); }
function setTab(which){
  tabs.forEach(t => t.classList.toggle('active', t.dataset.tab === which));
  presetPanel.classList.toggle('active', which === 'preset');
  personalPanel.classList.toggle('active', which === 'personal');
}
function nui(name, data = {}){
  return fetch(`https://${RES}/${name}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json; charset=utf-8' },
    body: JSON.stringify(data)
  }).then(r=>r.json()).catch(()=>({}));
}
function tryPlayAudio(){ const p = audioEl?.play?.(); if (p?.catch) p.catch(()=>{}); }

function makeCard(title, metaText, desc, outfit, extraButtons=[]){
  const card = document.createElement('div');
  card.className = 'card';

  const name = document.createElement('div');
  name.className = 'name';
  name.textContent = title;

  const meta = document.createElement('div');
  meta.className = 'meta';
  meta.textContent = metaText || '';

  const description = document.createElement('div');
  description.className = 'desc';
  description.textContent = (desc || '').trim();

  const actions = document.createElement('div');
  actions.className = 'actions';

  const wear = document.createElement('button');
  wear.className = 'btn primary btn-sm';
  wear.textContent = 'Wear';
  wear.addEventListener('click', async (e)=>{
    e.stopPropagation();
    await nui('outfit:equip', { outfit });
    tryPlayAudio();
    setVisible(false);
    await nui('ui:close', {});
  });

  actions.appendChild(wear);
  extraButtons.forEach(b => actions.appendChild(b));

  card.appendChild(name);
  if (metaText) card.appendChild(meta);
  if (description.textContent) card.appendChild(description);
  card.appendChild(actions);

  return card;
}

// Search by TITLE only (as requested)
function filterByTitle(list, q){
  if (!q) return list;
  const s = q.toLowerCase();
  return list.filter(it => (it.name || '').toLowerCase().includes(s));
}

function render(){
  // Presets
  presetGrid.innerHTML = '';
  filterByTitle(state.presets, state.qPresets).forEach(p=>{
    presetGrid.appendChild(
      makeCard(p.name, 'Preset', p.desc || '', { components:p.components, props:p.props })
    );
  });

  // Personal
  personalGrid.innerHTML = '';
  filterByTitle(state.personal.map(e=>({ name:e.name, desc:e.desc || '', outfit:e.outfit })), state.qPersonal)
    .forEach(entry=>{
      const del = document.createElement('button');
      del.className='btn btn-sm';
      del.textContent='Delete';
      del.addEventListener('click', async (e2)=>{
        e2.stopPropagation();
        const res = await nui('personal:delete', { name: entry.name });
        if (res.ok){ state.personal = res.personal || []; render(); }
      });

      personalGrid.appendChild(
        makeCard(entry.name, 'Personal', entry.desc || '', entry.outfit, [del])
      );
    });
}

tabs.forEach(tab => tab.addEventListener('click', ()=>setTab(tab.dataset.tab)));
closeBtn.addEventListener('click', async ()=>{ await nui('ui:close', {}); setVisible(false); });

saveBtn.addEventListener('click', async ()=>{
  const name = (saveName.value||'').trim();
  const desc = (saveDesc.value||'').trim();
  if (!name) return;
  const res = await nui('personal:save', { name, desc });
  if (res.ok){
    state.personal = res.personal || [];
    saveName.value = ''; saveDesc.value = '';
    setTab('personal');
    render();
  }
});

// Live filter (title-only)
searchInput.addEventListener('input', ()=>{ state.qPresets  = searchInput.value;  render(); });
searchPersonal.addEventListener('input', ()=>{ state.qPersonal = searchPersonal.value; render(); });

window.addEventListener('keydown', async (e)=>{
  if (e.key === 'Escape'){ await nui('ui:close', {}); setVisible(false); }
});

window.addEventListener('message', (event)=>{
  if (event.data?.action === 'open'){
    state.presets  = event.data.payload.presets  || [];
    state.personal = event.data.payload.personal || [];
    state.qPresets = ''; state.qPersonal = '';
    searchInput.value = ''; searchPersonal.value = '';
    setTab('preset'); render(); setVisible(true);
  } else if (event.data?.action === 'hardHide' || event.data?.action === 'hide'){
    setVisible(false);
  }
});

nui('ui:ready', {}); // doesn't open UI

window.addEventListener("message", (event) => {
  const data = event.data;

  if (data?.action === "playSound") {
    const audio = document.getElementById("locker-audio");
    if (audio) {
      audio.currentTime = 0;
      audio.play().catch((e) => {
        console.warn("Audio play failed:", e);
      });
    }
  }
});

